### Linux服务号部署（v4.8）

#### 1、服务号后端webhost修改配置文件

##### 	a.`appsettings.json`修改端口

##### 	b.`config`文件夹中`RekTec.XStudio.Data.DbSourceConfig.xml.config`修改数据库地址

##### 	d.`config`文件夹中`RekTec.XStudio.WeChatMp.WeChatMpConfig.xml`修改对应的`AppId`、`AppSecret`，并将`Token`和`EncodingAESKey`清空，`EncodingAESKey`中改成相应的地址，其中端口写中控的

#### 2、中控修改配置文件

##### 	a.`appsettings.json`修改端口

##### 	b.`config`文件夹中`RekTec.XStudio.WeChatMp.WeChatMpConfig.xml`修改对应的`AppId`、`AppSecret`，并将`Token`和`EncodingAESKey`清空。

#### 3、后端修改代码

##### 	a、`RegisteCommon`中的`CreateAccountOrContactWhenRegisterOnWechat`方法，将`identity.SystemUserId = this.CreateOrUpdateTempUserInfo(userId);`的`try-catch`拿掉

##### 	b、`WeixinSSOController`中覆盖`getRedirectUri`方法

> ​    private string getRedirectUri(string homeurl = null, string authorize = null)
> ​    {
> ​      //var redirect_url = "http://192.168.7.176:8086/wechat/autorize.html";
> ​      //var helper = this.Request.GetUrlHelper();
> ​      //var reqUri = this.Request.RequestUri;
>
> ​      StringBuilder sb = new StringBuilder(255);
> ​      /* 
> ​      sb.Append(reqUri.Scheme);
> ​      sb.Append("://");
> ​      sb.Append(reqUri.Host);
> ​      if (reqUri.Port != 80 && reqUri.Port != 443)
> ​        sb.Append(":" + reqUri.Port);
> */
> ​      var url = this.GetService<SystemParameterProvider>().GetParameterValue("WeChat_Url");
> ​      url = url.TrimEnd('/');
> ​      sb.Append(url);
> ​      if (!string.IsNullOrWhiteSpace(homeurl) && homeurl.Contains("gotochatpage"))
> ​      {
> ​        sb.Append("/");
> ​        sb.Append(homeurl);
> ​      }
> ​      else
> ​      {
> ​        if (!String.IsNullOrEmpty(authorize))
> ​        {
> ​          sb.Append("/#/weixinmp2/authorize2");
> ​        }
> ​        else
> ​        {
> ​          sb.Append("/#/weixinmp/authorize");
> ​        }
>
> ​      }
> ​      return sb.ToString();
> ​    }

 #### 4、发布`webhost`，并新建`wwwroot`放前端build文件，将中控包放入

4.1、公众号后台部署参考《服务号部署流程》

#### 5、创建服务文件

执行之前先创建一个无需登录用来运行服务的用户。

useradd -s /sbin/nologin -M ruiyun（用户名）

设置网站程序目录的用户和组都为上面创建的用户

chown -R ruiyun:ruiyun /db/www/website/sacon_mp/public（网站文件根目录）

文件名为 项目名-mp，中控文件名为项目名-mpcenter

内容如下

````shell
[Unit]
Description=OneSdk running on Centos

[Service]
WorkingDirectory=/db/www/website/sacon_mp/public  //工作目录
ExecStart=/usr/bin/dotnet /db/www/website/sacon_mp/public/Rektec.Service1WechatPublic.NetCore.WebHost.dll
Restart=always
RestartSec=10
KillSignal=SIGINT
SyslogIdentifier=sacon-mp //服务的前缀文件名
User=ruiyun --上面创建的无需登录用户
#Production: Development:
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=DOTNET_PRINT_TELEMETRY_MESSAGE=false

[Install]
WantedBy=multi-user.target
````

中控文件内容如下

```` shell
[Unit]
Description=OneSdk running on Centos

[Service]
WorkingDirectory=/db/www/website/sacon_mp/public/WechatCentralWeb//站点目录
ExecStart=/usr/bin/dotnet /db/www/website/sacon_mp/public/WechatCentralWeb/RekTec.WechatMp.NetCore.CentralWeb.dll//执行文件
Restart=always
RestartSec=10
KillSignal=SIGINT
SyslogIdentifier=sacon-mpcenter//服务的前缀文件名
User=ruiyun--上面创建的无需登录用户
#Production: Development:
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=DOTNET_PRINT_TELEMETRY_MESSAGE=false

[Install]
WantedBy=multi-user.target
````

**5.1、设置站点自启动  sudo systemctl enable xxx.service**

**5.2、启动站点 sudo systemctl start xxx.service**

**5.3、重启站点 sudo systemctl restart xxx.service(无需操作 这只是命令的记录)**

**5.4、验证本地访问站点的token是否成功**

![微信图片_20220307181954](C:\Users\23898\Desktop\微信图片_20220307181954.png)

**5.5、在服务器本地 curl http://localhost:8081/文件名  端口试appsettings.json里开放的端口  文件名是公众号后台的那个文件。**

**6、将打包的并配置好的文件放入服务器中**

##### 7、ping域名，将IP地址(curl http://api.ipify.org/)加入到安全中心的白名单

**8、确保对应云的对应的443端口是开放的 协议是Https**

![微信图片_20220307180828](C:\Users\23898\Desktop\微信图片_20220307180828.png)

**9、https://wx.sacon.cn/token  访问域名的token**

![image-20220307175958264](C:\Users\23898\AppData\Roaming\Typora\typora-user-images\image-20220307175958264.png)

**10、最后确保appid 和appsecret的正确性**

appsecret报错提示![微信图片_20220307182605](C:\Users\23898\Desktop\微信图片_20220307182605.jpg)

**11、天翼云的二级域名是映射到三网ip的所以转发策略是无效的，正常的域名映射到弹性公网ip就可以可以添加转发策略就行了**

![1646649207(1)](C:\Users\23898\Desktop\1646649207(1).png)

天翼云的需要在新添加的监听器里配置后端主机组   端口填后端appsettings.json里的端口